<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% dolazi na %contentTitle%.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% možda dolazi na %contentTitle%.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% ne dolazi na %contentTitle%.',
);
