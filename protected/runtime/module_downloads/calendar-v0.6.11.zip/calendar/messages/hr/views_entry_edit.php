<?php
return array (
  '<strong>Create</strong> event' => '<strong>Kreiraj</strong> događaj',
  '<strong>Edit</strong> event' => '<strong>Uredi</strong> događaj',
  'Basic' => 'Osnovno',
  'Everybody can participate' => 'Svi mogu sudjelovati',
  'Files' => 'Datoteke',
  'No participants' => 'Nema sudionika',
  'Participation' => 'Sudjelovanje',
  'Select event type...' => 'Odaberite tip događaja...',
  'Title' => 'Naziv',
);
