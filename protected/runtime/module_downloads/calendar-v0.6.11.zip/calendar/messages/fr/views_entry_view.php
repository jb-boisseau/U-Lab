<?php
return array (
  'Attend' => 'Participe',
  'Decline' => 'Décline',
  'Maybe' => 'Peut-être',
  'Participant information:' => 'Informations :',
  'Read full description...' => 'Lire la description complète...',
  'Read full participation info...' => 'Lire les informations complètes...',
);
