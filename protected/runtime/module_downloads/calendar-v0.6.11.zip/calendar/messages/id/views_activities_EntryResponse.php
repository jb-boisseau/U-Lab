<?php
return array (
  '%displayName% attends to %contentTitle%.' => 'bisa hadir ke',
  '%displayName% maybe attends to %contentTitle%.' => 'mungkin bisa hadir',
  '%displayName% not attends to %contentTitle%.' => 'tidak dapat hadir',
);
