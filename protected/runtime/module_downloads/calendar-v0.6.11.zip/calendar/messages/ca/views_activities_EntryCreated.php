<?php
return array (
  '%displayName% created a new %contentTitle%.' => '%displayName% ha creat un nou %contentTitle%.',
);
