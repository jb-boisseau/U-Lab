<?php
return array (
  '<strong>Create</strong> new event type' => '<strong>Opprett</strong> ny aktiviteststype',
  '<strong>Edit</strong> calendar' => '<strong>Rediger</strong> kalenderen',
  '<strong>Edit</strong> event type' => '<strong>Rediger</strong> aktivitetstype',
);
