<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Kommende</strong> aktiviteter',
  'Open Calendar' => 'Åpne Kalender',
);
