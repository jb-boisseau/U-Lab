<?php
return array (
  '<strong>Create</strong> event' => '<strong>Criar</strong> evento',
  '<strong>Edit</strong> event' => '<strong>Alterar</strong> evento',
  'Basic' => 'Básico',
  'Everybody can participate' => 'Todos podem participar',
  'Files' => 'Arquivos',
  'No participants' => 'Sem participantes',
  'Participation' => 'Participação',
  'Select event type...' => 'Selecionar tipo de evento...',
  'Title' => 'Título',
);
