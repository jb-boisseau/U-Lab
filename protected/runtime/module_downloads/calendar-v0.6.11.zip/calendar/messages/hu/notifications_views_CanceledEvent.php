<?php
return array (
  '{displayName} canceled event \'{contentTitle}\' in space {spaceName}.' => '{displayName} törölte a(z) \'{contentTitle}\' eseményt a(z) {spaceName}-n.',
  '{displayName} canceled event \'{contentTitle}\'.' => '{displayName} törölte a(z) \'{contentTitle}\' eseményt.',
  '{displayName} just updated event {contentTitle} in space {spaceName}.' => '{displayName} most frissítette a(z) {contentTitle} eseményt a(z) {spaceName}-n.',
  '{displayName} just updated event {contentTitle}.' => '{displayName} most frissítette a(z) {contentTitle} eseményt.',
  '{displayName} reopened event {contentTitle} in space {spaceName}.' => '{displayName} újranyitotta a(z) {contentTitle} eseményt a(z) {spaceName} -n.',
  '{displayName} reopened event {contentTitle}.' => '{displayName} újranyitotta a(z) {contentTitle} eseményt',
);
