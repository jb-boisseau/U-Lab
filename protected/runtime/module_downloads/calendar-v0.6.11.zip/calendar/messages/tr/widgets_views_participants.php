<?php
return array (
  ':count attending' => ':count katılan',
  ':count declined' => ':count katılmayan',
  ':count maybe' => ':count belki katılan',
  'Participants:' => 'Katılımcılar',
);
