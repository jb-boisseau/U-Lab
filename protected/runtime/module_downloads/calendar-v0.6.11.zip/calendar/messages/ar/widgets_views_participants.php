<?php
return array (
  ':count attending' => '',
  ':count declined' => '',
  ':count maybe' => '',
  'Participants:' => '',
);
