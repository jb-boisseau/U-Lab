<?php
return array (
  'Calendar' => 'Calendario',
  'Receive Calendar related Notifications.' => 'Recibir notificaciones del Calendario.',
);
