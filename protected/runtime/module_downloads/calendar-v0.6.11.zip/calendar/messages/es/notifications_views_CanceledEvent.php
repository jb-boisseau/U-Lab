<?php
return array (
  '{displayName} canceled event \'{contentTitle}\' in space {spaceName}.' => '{displayName} ha cancelado el evento \'{contentTitle}\' del espacio {spaceName}.',
  '{displayName} canceled event \'{contentTitle}\'.' => '{displayName} ha cancelado el evento \'{contentTitle}\'.',
  '{displayName} just updated event {contentTitle} in space {spaceName}.' => '{displayName} ha actualizado el evento {contentTitle} del espacio {spaceName}.',
  '{displayName} just updated event {contentTitle}.' => '{displayName} ha actualizado el evento {contentTitle}.',
  '{displayName} reopened event {contentTitle} in space {spaceName}.' => '{displayName} ha reabierto el evento {contentTitle} del espacio {spaceName}.',
  '{displayName} reopened event {contentTitle}.' => '{displayName} ha reabierto el evento {contentTitle}.',
);
